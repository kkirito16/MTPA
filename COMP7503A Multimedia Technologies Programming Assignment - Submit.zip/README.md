# Smart City Data Engine & Multimedia Dashboard

**Course:** COMP7503A Multimedia Technologies

**Project:** Smart City Data Engine using Node-RED, Docker, and MongoDB

## 👥 Team Members

- **Liu Junqi** (UID: 3036657445)
- **Wang Wenhan** (UID: 3036656398)

## 📂 Submission Structure

- `docker-compose.yml` \- Container orchestration file for Node-RED and MongoDB.  
- `SmartCity-Flow.json` \- The complete Node-RED source code (flows).  
- `COMP7503A Multimedia Technologies Programming Assignment - Project Report.pdf` \- Detailed documentation of architecture, algorithms, and insights.  
- `db_dump/` \- JSON exports of historical data (Temperature, AQHI, Mobility) for verifying analytics.

## 🚀 Quick Start Guide

### 1. Prerequisites

Ensure **Docker Desktop** is installed and running on your machine.

### 2. Launch System

Open a terminal in this folder and run:

```bash
docker-compose up -d
```

This will:

- Pull the custom Node-RED image (`edenwang33773/smartcity-nodered:final`) containing all necessary dependencies.  
- Start the MongoDB container (`Mymongo`) and initialize authentication.  
- Create a dedicated network `SmartCityNet`.

### 3. Access Dashboard

Once the containers are running, open your browser:

- **Dashboard UI:** [http://localhost:1880/ui](http://localhost:1880/ui)  
- **Node-RED Editor:** [http://localhost:1880](http://localhost:1880)

## 💾 Database & Historical Data

**Note:** The Docker containers start with a fresh, empty database. To visualize historical trends (e.g., the 24-hour traffic curve) immediately without waiting for new data collection, please import the provided data files.

### Data Files (in `db_dump/` folder)

1. `test.Weather Report.json`
2. `test.aqhi_data.json`
3. `test.mobility_data.json`

### Credentials for MongoDB (if needed)

- **Username:** admin  
- **Password:** 666712  
- **Port:** 27017

## 🛠️ Architecture Highlights

- **Ingestion:** Real-time integration of HKO, EPD, and TD government APIs.  
- **Analytics:** Custom JavaScript algorithms for Pearson Correlation and Data Aggregation.  
- **Visualization:** Responsive Dashboard with real-time gauges and historical trend charts.
